package mypack;
public class met2 

{
  public int Getbillof(int c,int m[])
    {
        String[] Total= {" "," "," "," "," "," "," "," "," "};
        int a =0;
        switch(c)
        {
            case 1:
            {
                String[] MENU= {" ","Baguette","Escargot", "Onion Soup", "Croque Monsieur","Nicoise Salad","Ratatouille","Coq au Vin","Dauphinois Potatoes","Croissant","Quiche Lorraine"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 2:
            {
                String[] MENU= {" ","Peking Duck","Sweet and Sour Pork", "Dim Sum", "Kung Pao Chicken","Mapo Tofu","Hot Pot","Chow Mein","Xiaolongbao","Fried Rice","Spring Rolls"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 3:
            {
                String[] MENU= {" ","Pizza Margherita","Spaghetti Carbonara", "Lasagna", "Risotto","Tiramisu","Fettuccine Alfredo","Bruschetta","Prosciutto e Melone","Osso Buco","Panna Cotta"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 4:
            {
                String[] MENU= {" ","Moussaka","Souvlaki", "Tzatziki", "Greek Salad (Horiatiki)","Spanakopita","Gyro","Baklava","Dolmades","Kleftiko","Fasolada"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 5:
            {
                String[] MENU= {" ","Paella","Tapas", " Tortilla", "Gazpacho","Fabada Asturiana","Patatas Bravas","Jamón Ibérico","Pulpo a la Gallega","Croquetas","Pisto"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 6:
            {
                String[] MENU= {" ","Peking Duck","Sweet and Sour Pork", "Dim Sum", "Kung Pao Chicken","Mapo Tofu","Hot Pot","Chow Mein","Xiaolongbao","Fried Rice","Spring Rolls"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 7:
            {
                String[] MENU= {" ","Pizza Margherita","Spaghetti Carbonara", "Lasagna", "Risotto","Tiramisu","Fettuccine Alfredo","Bruschetta","Prosciutto e Melone","Osso Buco","Panna Cotta"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 8:
            {
                String[] MENU= {" ","Moussaka","Souvlaki", "Tzatziki", "Greek Salad (Horiatiki)","Spanakopita","Gyro","Baklava","Dolmades","Kleftiko","Fasolada"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
        }
        return a;
    }  
}