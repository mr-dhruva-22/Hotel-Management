package mypack;
import java.util.*;

public class met1
{
    int food[]=new int [11];
    public int[] Getfoodof(int a)
    {
        Scanner ac=new Scanner(System.in);
        switch(a)
        {
            case 1:
            {
             food[10] = 1;
             char c='f';   
             System.out.println("Bonjour!");
             System.out.println("                                       ");
             System.out.println("1.Baguette: The classic French bread.");
             System.out.println("2.Escargot: The famous (or infamous) dish made from snails.");
             System.out.println("3.Onion Soup: A popular soup.");
             System.out.println("4.Croque Monsieur: A wonderful winter dish.");
             System.out.println("5.Nicoise Salad: A salad with tuna, olives, and other ingredients.");
             System.out.println("6.Ratatouille: A vegetable stew.");
             System.out.println("7.Coq au Vin: A chicken dish cooked in wine.");
             System.out.println("8.Dauphinois Potatoes: A gratin dish made with sliced potatoes.");
             System.out.println("9.Croissant: A crescent-shaped pastry.");
             System.out.println("10.Quiche Lorraine:A savory pie from the Lorraine region");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
             if(food[0]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[0]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[0]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[0]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[0]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[0]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[0]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[0]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[0]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[0]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[1]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[1]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[1]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[1]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[1]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[1]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[1]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[1]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[1]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[2]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[2]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[2]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[2]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[2]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[2]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[2]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[2]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[2]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[3]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[3]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[3]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[3]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[3]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[3]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[3]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[3]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[3]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[4]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[4]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[4]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[4]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[4]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[4]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[4]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[4]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[4]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[5]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[5]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[5]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[5]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[5]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[5]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[5]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[5]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[5]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[6]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[6]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[6]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[6]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[6]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[6]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[6]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[6]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[6]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[7]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[7]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[7]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[7]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[7]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[7]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[7]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[7]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[7]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[8]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[8]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[8]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[8]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[8]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[8]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[8]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[8]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[8]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Baguette");
             }
             if(food[9]==2)
             {
             System.out.println("2.Escargot");
             }
             if(food[9]==3)
             {
              System.out.println("3.Onion Soup");
             }
             if(food[9]==4)
             {
              System.out.println("4.Croque Monsieur");
             }
             if(food[9]==5)
             {
              System.out.println("5.Nicoise Salad");
             }
             if(food[9]==6)
             {
              System.out.println("6.Ratatouille");
             }
             if(food[9]==7)
             {
              System.out.println("7.Coq au Vin");
             }
             if(food[9]==8)
             {
              System.out.println("8.Dauphinois");
             }
             if(food[9]==9)
             {
              System.out.println("9.Croissant");
             }
             if(food[9]==10)
             {
              System.out.println("10.Quiche Lorraine");
             }
             break;
            }
            case 2:
            {
             food[10] = 2;
             char c='c';
             System.out.println("nǐhǎo!"); 
             System.out.println("                                       ");
             System.out.println("1.Peking Duck (Beijing Roast Duck) – Crispy skin and tender meat served with pancakes and hoisin sauce. ");
             System.out.println("2.Sweet and Sour Pork – A tangy-sweet dish with fried pork in a vibrant sauce. ");
             System.out.println("3.Dim Sum – A variety of small, bite-sized snacks like dumplings, buns, and rolls, typically served with tea. ");
             System.out.println("4.Kung Pao Chicken – Stir-fried chicken with peanuts, chili peppers, and a savory sauce.");
             System.out.println("5.Mapo Tofu – A spicy Sichuan dish made of tofu in a bold, chili bean sauce with minced pork.");
             System.out.println("6.Hot Pot – A communal meal where ingredients are cooked in a boiling pot of broth at the table.");
             System.out.println("7.Chow Mein – Stir-fried noodles with vegetables and meat or seafood, a classic comfort dish.");
             System.out.println("8.Xiaolongbao (Soup Dumplings) – Delicate dumplings filled with hot broth and minced meat.");
             System.out.println("9.Fried Rice – Rice stir-fried with vegetables, eggs, and sometimes meat or seafood, seasoned to perfection.");
             System.out.println("10.Spring Rolls – Crispy rolls filled with vegetables or meat, deep-fried and served with dipping sauces.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[0]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[0]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[0]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[0]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[0]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[0]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[0]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[0]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[0]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[1]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[1]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[1]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[1]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[1]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[1]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[1]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[1]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[1]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[2]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[2]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[2]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[2]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[2]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[2]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[2]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[2]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[2]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[3]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[3]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[3]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[3]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[3]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[3]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[3]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[3]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[3]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[4]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[4]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[4]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[4]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[4]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[4]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[4]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[4]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[4]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[5]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[5]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[5]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[5]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[5]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[5]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[5]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[5]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[5]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[6]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[6]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[6]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[6]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[6]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[6]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[6]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[6]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[6]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[7]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[7]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[7]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[7]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[7]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[7]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[7]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[7]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[7]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[8]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[8]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[8]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[8]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[8]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[8]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[8]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[8]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[8]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Peking Duck");
             }
             if(food[9]==2)
             {
             System.out.println("2.Sweet and Sour Pork");
             }
             if(food[9]==3)
             {
              System.out.println("3.Dim Sum");
             }
             if(food[9]==4)
             {
              System.out.println("4.Kung Pao Chicken");
             }
             if(food[9]==5)
             {
              System.out.println("5.Mapo Tofu");
             }
             if(food[9]==6)
             {
              System.out.println("6.Hot Pot");
             }
             if(food[9]==7)
             {
              System.out.println("7.Chow Mein");
             }
             if(food[9]==8)
             {
              System.out.println("8.Xiaolongbao");
             }
             if(food[9]==9)
             {
              System.out.println("9.Fried Rice");
             }
             if(food[9]==10)
             {
              System.out.println("10.Spring Rolls");
             }
             break;
            }
            case 3:
            {
             food[10] = 3;
             char c='i';
             System.out.println("Ciao!"); 
             System.out.println("                                       ");
             System.out.println("1.Pizza Margherita – A simple yet iconic pizza topped with tomatoes, mozzarella, and fresh basil. ");
             System.out.println("2.Spaghetti Carbonara – A rich pasta dish made with eggs, cheese, pancetta, and black pepper. ");
             System.out.println("3.Lasagna – Layers of pasta, meat sauce, béchamel, and cheese baked to perfection. ");
             System.out.println("4.Risotto – Creamy rice cooked with broth, often featuring saffron, mushrooms, or seafood.");
             System.out.println("5.Tiramisu – A coffee-flavored dessert made with layers of mascarpone, ladyfingers, and cocoa.");
             System.out.println("6.Fettuccine Alfredo – A pasta dish coated in a creamy Parmesan cheese and butter sauce.");
             System.out.println("7.Bruschetta – Grilled bread topped with garlic, tomatoes, olive oil, and fresh herbs.");
             System.out.println("8.Prosciutto e Melone – A simple appetizer of cured ham served with sweet, ripe melon.");
             System.out.println("9.Osso Buco – Braised veal shanks cooked with white wine, vegetables, and broth.");
             System.out.println("10.Panna Cotta – A silky-smooth dessert made from sweetened cream and served with fruit or caramel.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[0]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[0]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[0]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[0]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[0]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[0]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[0]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[0]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[0]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[1]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[1]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[1]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[1]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[1]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[1]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[1]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[1]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[1]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[2]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[2]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[2]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[2]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[2]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[2]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[2]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[2]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[2]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[3]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[3]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[3]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[3]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[3]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[3]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[3]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[3]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[3]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[4]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[4]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[4]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[4]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[4]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[4]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[4]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[4]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[4]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[5]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[5]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[5]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[5]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[5]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[5]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[5]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[5]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[5]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[6]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[6]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[6]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[6]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[6]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[6]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[6]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[6]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[6]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[7]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[7]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[7]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[7]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[7]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[7]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[7]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[7]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[7]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[8]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[8]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[8]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[8]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[8]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[8]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[8]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[8]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[8]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Pizza Margherita");
             }
             if(food[9]==2)
             {
             System.out.println("2.Spaghetti Carbonara");
             }
             if(food[9]==3)
             {
              System.out.println("3.Lasagna");
             }
             if(food[9]==4)
             {
              System.out.println("4.Risotto");
             }
             if(food[9]==5)
             {
              System.out.println("5.Tiramisu");
             }
             if(food[9]==6)
             {
              System.out.println("6.Fettuccine Alfredo");
             }
             if(food[9]==7)
             {
              System.out.println("7.Bruschetta");
             }
             if(food[9]==8)
             {
              System.out.println("8.Prosciutto e Melone");
             }
             if(food[9]==9)
             {
              System.out.println("9.Osso Buco");
             }
             if(food[9]==10)
             {
              System.out.println("10.Panna Cotta");
             }
             break;
            }
            case 4:
            {
             food[10] = 4;
             char c='g';
             System.out.println("geia sas!"); 
             System.out.println("                                       ");
             System.out.println("1.Moussaka – A layered casserole with eggplant, ground meat, and béchamel sauce. ");
             System.out.println("2.Souvlaki – Grilled skewers of marinated meat, often served in pita bread with tzatziki. ");
             System.out.println("3.Tzatziki – A refreshing dip made from yogurt, cucumber, garlic, and olive oil. ");
             System.out.println("4.Greek Salad (Horiatiki) – A simple salad with tomatoes, cucumbers, olives, onions, feta cheese, and olive oil.");
             System.out.println("5.Spanakopita – A savory spinach and feta pie wrapped in flaky phyllo dough.");
             System.out.println("6.Gyro – Thinly sliced, spiced meat (usually lamb or chicken) served in pita bread with toppings and tzatziki.");
             System.out.println("7.Baklava – A sweet dessert made of layers of phyllo pastry filled with nuts and honey syrup.");
             System.out.println("8.Dolmades – Grape leaves stuffed with rice, herbs, and sometimes meat, served cold or warm.");
             System.out.println("9.Kleftiko – Slow-cooked lamb marinated with garlic, lemon, and herbs, wrapped in parchment.");
             System.out.println("10.Fasolada – A hearty bean soup made with tomatoes, olive oil, and vegetables, often referred to as the national dish of Greece.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[0]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[0]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[0]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[0]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[0]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[0]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[0]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[0]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[0]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[1]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[1]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[1]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[1]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[1]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[1]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[1]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[1]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[1]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[2]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[2]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[2]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[2]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[2]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[2]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[2]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[2]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[2]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[3]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[3]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[3]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[3]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[3]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[3]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[3]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[3]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[3]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[4]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[4]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[4]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[4]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[4]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[4]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[4]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[4]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[4]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[5]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[5]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[5]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[5]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[5]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[5]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[5]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[5]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[5]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[6]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[6]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[6]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[6]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[6]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[6]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[6]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[6]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[6]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[7]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[7]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[7]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[7]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[7]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[7]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[7]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[7]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[7]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[8]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[8]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[8]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[8]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[8]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[8]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[8]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[8]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[8]==10)
             {
              System.out.println("10.Fasolada");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Moussaka");
             }
             if(food[9]==2)
             {
             System.out.println("2.Souvlaki");
             }
             if(food[9]==3)
             {
              System.out.println("3.Tzatziki");
             }
             if(food[9]==4)
             {
              System.out.println("4.Greek Salad");
             }
             if(food[9]==5)
             {
              System.out.println("5.Spanakopita");
             }
             if(food[9]==6)
             {
              System.out.println("6.Gyro");
             }
             if(food[9]==7)
             {
              System.out.println("7.Baklava");
             }
             if(food[9]==8)
             {
              System.out.println("8.Dolmades");
             }
             if(food[9]==9)
             {
              System.out.println("9.Kleftiko");
             }
             if(food[9]==10)
             {
              System.out.println("10.Fasolada");
             }
             break;
            }
            case 5:
            {
             food[10] = 5;
             char c='s';
             System.out.println("Hola!"); 
             System.out.println("                                       ");
             System.out.println("1.Paella – A vibrant rice dish cooked with saffron, seafood, chicken, or rabbit, originating from Valencia. ");
             System.out.println("2.Tapas – A variety of small appetizers, such as olives, jamón, and cheeses, served with drinks. ");
             System.out.println("3.Tortilla Española – A thick omelette made with eggs, potatoes, and onions, served hot or cold. ");
             System.out.println("4.Gazpacho – A refreshing cold soup made from blended tomatoes, cucumbers, peppers, and olive oil.");
             System.out.println("5.Fabada Asturiana – A rich and hearty bean stew from Asturias, made with large white beans, chorizo, morcilla (blood sausage), and pork shoulder.");
             System.out.println("6.Patatas Bravas – Fried potatoes served with a spicy tomato sauce or aioli.");
             System.out.println("7.Jamón Ibérico – A prized cured ham from black Iberian pigs, sliced thin and eaten as a delicacy.");
             System.out.println("8.Pulpo a la Gallega – Octopus cooked with paprika, olive oil, and potatoes, a specialty from Galicia.");
             System.out.println("9.Croquetas – Small fried bites filled with béchamel and ham, chicken, or cheese.");
             System.out.println("10.Pisto – A Spanish ratatouille made with tomatoes, peppers, zucchini, and onions, often served with a fried egg.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[0]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[0]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[0]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[0]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[0]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[0]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[0]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[0]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[0]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[1]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[1]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[1]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[1]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[1]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[1]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[1]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[1]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[1]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[2]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[2]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[2]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[2]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[2]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[2]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[2]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[2]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[2]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[3]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[3]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[3]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[3]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[3]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[3]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[3]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[3]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[3]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[4]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[4]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[4]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[4]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[4]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[4]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[4]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[4]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[4]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[5]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[5]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[5]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[5]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[5]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[5]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[5]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[5]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[5]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[6]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[6]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[6]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[6]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[6]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[6]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[6]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[6]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[6]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[7]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[7]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[7]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[7]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[7]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[7]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[7]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[7]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[7]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[8]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[8]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[8]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[8]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[8]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[8]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[8]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[8]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[8]==10)
             {
              System.out.println("10.Pisto");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Paella");
             }
             if(food[9]==2)
             {
             System.out.println("2.Tapas");
             }
             if(food[9]==3)
             {
              System.out.println("3.Tortilla Española");
             }
             if(food[9]==4)
             {
              System.out.println("4.Gazpacho");
             }
             if(food[9]==5)
             {
              System.out.println("5.Fabada Asturiana");
             }
             if(food[9]==6)
             {
              System.out.println("6.Patatas Bravas");
             }
             if(food[9]==7)
             {
              System.out.println("7.Jamón Ibérico");
             }
             if(food[9]==8)
             {
              System.out.println("8.Pulpo a la Gallega");
             }
             if(food[9]==9)
             {
              System.out.println("9.Croquetas");
             }
             if(food[9]==10)
             {
              System.out.println("10.Pisto");
             }
             break;
            }
            case 6:
            {
             food[10] = 6;
             char c='l';
             System.out.println("marhaba!"); 
             System.out.println("                                       ");
             System.out.println("1.Hummus – A creamy dip made from blended chickpeas, tahini, lemon juice, and garlic. ");
             System.out.println("2.Tabbouleh – A fresh salad made of parsley, bulgur, tomatoes, mint, and a lemon-olive oil dressing. ");
             System.out.println("3.Falafel – Deep-fried balls or patties made from ground chickpeas, herbs, and spices. ");
             System.out.println("4.Kibbeh – A dish made of bulgur, minced onions, and finely ground meat (usually lamb), shaped into balls or patties.");
             System.out.println("5.Shawarma – Marinated and spit-roasted meat (usually lamb or chicken) served in pita with toppings.");
             System.out.println("6.Baba Ghanoush – A smoky, creamy dip made from roasted eggplant, tahini, lemon, and garlic.");
             System.out.println("7.Manakish – A Lebanese flatbread often topped with za'atar (a blend of herbs and sesame seeds) or cheese.");
             System.out.println("8.Fattoush – A vibrant salad made with crispy pieces of pita bread, mixed greens, and a tangy pomegranate dressing.");
             System.out.println("9.Warak Enab (Stuffed Grape Leaves) – Grape leaves stuffed with rice, tomatoes, and sometimes meat, cooked with olive oil and lemon.");
             System.out.println("10.Baklava – A sweet, layered pastry filled with nuts and soaked in syrup, a staple in Lebanese desserts.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[0]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[0]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[0]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[0]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[0]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[0]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[0]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[0]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[0]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[1]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[1]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[1]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[1]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[1]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[1]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[1]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[1]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[1]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[2]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[2]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[2]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[2]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[2]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[2]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[2]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[2]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[2]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[3]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[3]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[3]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[3]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[3]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[3]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[3]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[3]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[3]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[4]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[4]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[4]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[4]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[4]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[4]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[4]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[4]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[4]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[5]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[5]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[5]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[5]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[5]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[5]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[5]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[5]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[5]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[6]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[6]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[6]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[6]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[6]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[6]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[6]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[6]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[6]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[7]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[7]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[7]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[7]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[7]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[7]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[7]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[7]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[7]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[8]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[8]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[8]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[8]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[8]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[8]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[8]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[8]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[8]==10)
             {
              System.out.println("10.Baklava");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Hummus");
             }
             if(food[9]==2)
             {
             System.out.println("2.Tabbouleh");
             }
             if(food[9]==3)
             {
              System.out.println("3.Falafel");
             }
             if(food[9]==4)
             {
              System.out.println("4.Kibbeh");
             }
             if(food[9]==5)
             {
              System.out.println("5.Shawarma");
             }
             if(food[9]==6)
             {
              System.out.println("6.Baba Ghanoush");
             }
             if(food[9]==7)
             {
              System.out.println("7.Manakish");
             }
             if(food[9]==8)
             {
              System.out.println("8.Fattoush");
             }
             if(food[9]==9)
             {
              System.out.println("9.Warak Enab");
             }
             if(food[9]==10)
             {
              System.out.println("10.Baklava");
             }
             break;
            }
            case 7:
            {
             food[10] = 7;
             char c='m';
             System.out.println("marhaba!");  
             System.out.println("                                       ");
             System.out.println("1.Tagine – A slow-cooked stew of meat, vegetables, and spices, named after the clay pot it's cooked in. ");
             System.out.println("2.Couscous – Steamed semolina grains typically served with vegetables and meat or fish. ");
             System.out.println("3.Harira – A rich tomato-based soup with lentils, chickpeas, and lamb, often eaten during Ramadan. ");
             System.out.println("4.Pastilla (Bastilla) – A savory-sweet pie made with layers of phyllo dough, pigeon or chicken, and almonds.");
             System.out.println("5.Mechoui – A whole roasted lamb, typically seasoned with cumin and herbs, served at special occasions.    ");
             System.out.println("6.Zaalouk – A smoky, flavorful eggplant and tomato dip, often served as a side or appetizer.");
             System.out.println("7.Rfissa – A dish of chicken and lentils served over shredded, steamed flatbread with fenugreek and spices.");
             System.out.println("8.Briouats – Small, crispy pastries stuffed with meat, seafood, or sweet almond paste.");
             System.out.println("9.Chebakia – A sesame cookie twisted into a flower shape, fried, and coated in honey, popular during Ramadan.");
             System.out.println("10.Msemen – A layered, buttery flatbread served plain or with honey, often eaten for breakfast or snacks.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[0]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[0]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[0]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[0]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[0]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[0]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[0]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[0]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[0]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[1]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[1]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[1]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[1]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[1]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[1]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[1]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[1]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[1]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[2]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[2]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[2]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[2]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[2]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[2]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[2]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[2]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[2]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[3]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[3]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[3]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[3]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[3]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[3]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[3]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[3]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[3]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[4]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[4]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[4]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[4]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[4]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[4]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[4]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[4]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[4]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[5]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[5]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[5]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[5]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[5]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[5]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[5]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[5]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[5]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[6]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[6]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[6]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[6]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[6]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[6]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[6]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[6]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[6]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[7]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[7]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[7]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[7]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[7]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[7]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[7]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[7]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[7]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[8]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[8]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[8]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[8]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[8]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[8]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[8]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[8]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[8]==10)
             {
              System.out.println("10.Msemen");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Tagine");
             }
             if(food[9]==2)
             {
             System.out.println("2.Couscous");
             }
             if(food[9]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[9]==4)
             {
              System.out.println("4.Pastilla");
             }
             if(food[9]==5)
             {
              System.out.println("5.Mechoui");
             }
             if(food[9]==6)
             {
              System.out.println("6.Zaalouk");
             }
             if(food[9]==7)
             {
              System.out.println("7.Rfissa");
             }
             if(food[9]==8)
             {
              System.out.println("8.Briouats");
             }
             if(food[9]==9)
             {
              System.out.println("9.Chebakia");
             }
             if(food[9]==10)
             {
              System.out.println("10.Msemen");
             }
             break;
            }
            case 8:
            {
             food[10] = 8;
             char c='u';
             System.out.println("Merhaba!"); 
             System.out.println("                                       ");
             System.out.println("1.Kebabs (Shish, Döner, Adana) – Various types of grilled or spit-roasted meat, seasoned with spices and herbs. ");
             System.out.println("2.Baklava – A sweet pastry made of thin layers of phyllo dough, filled with chopped nuts and drenched in syrup. ");
             System.out.println("3.Lahmacun – A thin, crispy flatbread topped with spiced minced meat, onions, and tomatoes. ");
             System.out.println("4.Menemen – Scrambled eggs cooked with tomatoes, green peppers, and spices, typically served for breakfast.");
             System.out.println("5.Meze – A selection of small dishes like hummus, stuffed grape leaves, and yogurt dips served as appetizers.");
             System.out.println("6.Dolma – Vegetables (like peppers or grape leaves) stuffed with a mixture of rice, herbs, and sometimes meat.");
             System.out.println("7.Manti – Turkish dumplings filled with minced meat, served with yogurt and garlic sauce.");
             System.out.println("8.Pide – A boat-shaped Turkish flatbread, often filled with cheese, ground meat, or vegetables.");
             System.out.println("9.Künefe – A dessert made from shredded phyllo dough filled with cheese, soaked in sweet syrup.");
             System.out.println("10.Börek – A savory pastry made from thin layers of dough, stuffed with cheese, spinach, or minced meat.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[0]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[0]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[0]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[0]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[0]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[0]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[0]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[0]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[0]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[1]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[1]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[1]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[1]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[1]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[1]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[1]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[1]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[1]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[2]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[2]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[2]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[2]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[2]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[2]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[2]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[2]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[2]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[3]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[3]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[3]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[3]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[3]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[3]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[3]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[3]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[3]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[4]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[4]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[4]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[4]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[4]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[4]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[4]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[4]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[4]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[5]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[5]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[5]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[5]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[5]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[5]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[5]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[5]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[5]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[6]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[6]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[6]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[6]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[6]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[6]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[6]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[6]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[6]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[7]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[7]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[7]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[7]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[7]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[7]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[7]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[7]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[7]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[8]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[8]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[8]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[8]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[8]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[8]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[8]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[8]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[8]==10)
             {
              System.out.println("10.Börek");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Kebabs");
             }
             if(food[9]==2)
             {
             System.out.println("2.Baklava");
             }
             if(food[9]==3)
             {
              System.out.println("3.Harira");
             }
             if(food[9]==4)
             {
              System.out.println("4.Menemen");
             }
             if(food[9]==5)
             {
              System.out.println("5.Meze");
             }
             if(food[9]==6)
             {
              System.out.println("6.Dolma");
             }
             if(food[9]==7)
             {
              System.out.println("7.Manti");
             }
             if(food[9]==8)
             {
              System.out.println("8.Pide");
             }
             if(food[9]==9)
             {
              System.out.println("9.Künefe");
             }
             if(food[9]==10)
             {
              System.out.println("10.Börek");
             }
             break;
            }
            case 9:
            {
             food[10] = 9;
             char c ='h';
             System.out.println("sah-wah-dee!");
             System.out.println("                                       ");
             System.out.println("1.Pad Thai – Stir-fried rice noodles with shrimp or chicken, eggs, peanuts, bean sprouts, and tamarind sauce. ");
             System.out.println("2.Tom Yum Goong (Spicy Shrimp Soup) – A hot and sour soup with shrimp, lemongrass, chili, and lime. ");
             System.out.println("3.Green Curry (Gaeng Keow Wan) – A creamy, spicy curry made with coconut milk, green chilies, and Thai basil. ");
             System.out.println("4.Som Tum (Papaya Salad) – A spicy and tangy salad made with shredded green papaya, lime, chili, and peanuts.");
             System.out.println("5.Massaman Curry – A rich, mild curry with tender beef, potatoes, and peanuts, flavored with cinnamon and cardamom.");
             System.out.println("6.Pad Kra Pao (Basil Chicken) – Stir-fried minced chicken with Thai basil, garlic, and chili, usually served with rice and a fried egg.");
             System.out.println("7.Tom Kha Gai (Coconut Chicken Soup) – A fragrant coconut milk soup with chicken, lemongrass, and galangal.");
             System.out.println("8.Mango Sticky Rice – A sweet dessert of ripe mango slices served with sticky rice and coconut milk.");
             System.out.println("9.Panang Curry – A thick, mild curry made with peanuts, coconut milk, and kaffir lime leaves.");
             System.out.println("10.Thai Satay – Grilled marinated meat skewers served with a flavorful peanut dipping sauce.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[0]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[0]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[0]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[0]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[0]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[0]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[0]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[0]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[0]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[1]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[1]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[1]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[1]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[1]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[1]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[1]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[1]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[1]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[2]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[2]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[2]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[2]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[2]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[2]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[2]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[2]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[2]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[3]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[3]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[3]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[3]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[3]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[3]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[3]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[3]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[3]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[4]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[4]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[4]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[4]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[4]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[4]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[4]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[4]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[4]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[5]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[5]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[5]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[5]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[5]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[5]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[5]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[5]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[5]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[6]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[6]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[6]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[6]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[6]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[6]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[6]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[6]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[6]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[7]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[7]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[7]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[7]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[7]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[7]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[7]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[7]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[7]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[8]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[8]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[8]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[8]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[8]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[8]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[8]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[8]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[8]==10)
             {
              System.out.println("10.Thai Satay");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Pad Thai");
             }
             if(food[9]==2)
             {
             System.out.println("2.Tom Yum Goong");
             }
             if(food[9]==3)
             {
              System.out.println("3.Green Curry");
             }
             if(food[9]==4)
             {
              System.out.println("4.Som Tum");
             }
             if(food[9]==5)
             {
              System.out.println("5.Massaman Curry");
             }
             if(food[9]==6)
             {
              System.out.println("6.Pad Kra Pao");
             }
             if(food[9]==7)
             {
              System.out.println("7.Tom Kha Gai");
             }
             if(food[9]==8)
             {
              System.out.println("8.Mango Sticky Rice");
             }
             if(food[9]==9)
             {
              System.out.println("9.Panang Curry");
             }
             if(food[9]==10)
             {
              System.out.println("10.Thai Satay");
             }
             break;
            }
            case 10:
            {
             food[10] = 10;
                char c='b';
             System.out.println("Olá!");  
             System.out.println("                                       ");
             System.out.println("1.Feijoada – A hearty black bean stew with pork, often considered Brazil’s national dish. ");
             System.out.println("2.Pão de Queijo – Chewy, bite-sized cheese bread made with cassava flour. ");
             System.out.println("3.Coxinha – Deep-fried dough filled with shredded chicken and cream cheese, shaped like a teardrop. ");
             System.out.println("4.Brigadeiro – A sweet chocolate truffle made with condensed milk, cocoa, and butter, rolled in sprinkles.");
             System.out.println("5.Churrasco – Brazilian barbecue featuring various cuts of grilled meats, often served on skewers.");
             System.out.println("6.Acarajé – Deep-fried balls of mashed black-eyed peas, stuffed with shrimp, onions, and spicy sauces.");
             System.out.println("7.Moqueca – A flavorful seafood stew with coconut milk, tomatoes, onions, and cilantro.");
             System.out.println("8.Farofa – Toasted cassava flour often mixed with bacon, used as a crunchy side dish.");
             System.out.println("9.Vatapá – A creamy dish made from shrimp, coconut milk, bread, and peanuts or cashews.");
             System.out.println("10.Pastel – Crispy, deep-fried pastry pockets filled with savory or sweet ingredients, like meat, cheese, or guava.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[0]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[0]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[0]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[0]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[0]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[0]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[0]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[0]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[0]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[1]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[1]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[1]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[1]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[1]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[1]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[1]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[1]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[1]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[2]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[2]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[2]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[2]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[2]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[2]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[2]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[2]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[2]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[3]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[3]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[3]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[3]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[3]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[3]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[3]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[3]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[3]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[4]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[4]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[4]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[4]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[4]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[4]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[4]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[4]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[4]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[5]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[5]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[5]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[5]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[5]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[5]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[5]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[5]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[5]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[6]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[6]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[6]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[6]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[6]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[6]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[6]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[6]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[6]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[7]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[7]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[7]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[7]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[7]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[7]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[7]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[7]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[7]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[8]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[8]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[8]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[8]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[8]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[8]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[8]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[8]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[8]==10)
             {
              System.out.println("10.Pastel");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Feijoada");
             }
             if(food[9]==2)
             {
             System.out.println("2.Pão de Queijo");
             }
             if(food[9]==3)
             {
              System.out.println("3.Coxinha");
             }
             if(food[9]==4)
             {
              System.out.println("4.Brigadeiro");
             }
             if(food[9]==5)
             {
              System.out.println("5.Churrasco");
             }
             if(food[9]==6)
             {
              System.out.println("6.Acarajé");
             }
             if(food[9]==7)
             {
              System.out.println("7.Moqueca");
             }
             if(food[9]==8)
             {
              System.out.println("8.Farofa");
             }
             if(food[9]==9)
             {
              System.out.println("9.Vatapá");
             }
             if(food[9]==10)
             {
              System.out.println("10.Pastel");
             }
             break;
            }
            case 11:
            {
             food[10] = 11; 
                char c='e';
             System.out.println("seh-lahm!");
             System.out.println("                                       ");
             System.out.println("1.Injera – A sour, spongy flatbread made from teff, used as a base and utensil for Ethiopian dishes. ");
             System.out.println("2.Doro Wat – A spicy chicken stew made with berbere spices, often served with hard-boiled eggs. ");
             System.out.println("3.Tibs – Sautéed or grilled meat (usually beef or lamb) cooked with onions, garlic, and spices.");
             System.out.println("4.Kitfo – Minced raw beef seasoned with spices and clarified butter, sometimes served lightly cooked.");
             System.out.println("5.Shiro – A thick, flavorful stew made from ground chickpeas or lentils, seasoned with berbere.");
             System.out.println("6.Berbere – A vibrant spice blend made of chili, garlic, ginger, and other spices, used in many Ethiopian dishes.");
             System.out.println("7.Misir Wat – A spiced red lentil stew cooked with berbere and niter kibbeh (spiced clarified butter).");
             System.out.println("8.Firfir – Shredded injera mixed with spices and clarified butter, often served with beef or lamb.");
             System.out.println("9.Awaze Tibs – A spicy version of tibs cooked with awaze (a hot pepper paste).");
             System.out.println("10.Gomen – Collard greens simmered with garlic, onions, and spices, often served as a side dish.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[0]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[0]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[0]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[0]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[0]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[0]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[0]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[0]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[0]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[1]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[1]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[1]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[1]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[1]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[1]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[1]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[1]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[1]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[2]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[2]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[2]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[2]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[2]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[2]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[2]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[2]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[2]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[3]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[3]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[3]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[3]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[3]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[3]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[3]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[3]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[3]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[4]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[4]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[4]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[4]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[4]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[4]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[4]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[4]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[4]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[5]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[5]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[5]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[5]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[5]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[5]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[5]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[5]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[5]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[6]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[6]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[6]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[6]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[6]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[6]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[6]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[6]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[6]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[7]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[7]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[7]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[7]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[7]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[7]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[7]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[7]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[7]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[8]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[8]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[8]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[8]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[8]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[8]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[8]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[8]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[8]==10)
             {
              System.out.println("10.Gomen");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Injera");
             }
             if(food[9]==2)
             {
             System.out.println("2.Doro Wat");
             }
             if(food[9]==3)
             {
              System.out.println("3.Tibs");
             }
             if(food[9]==4)
             {
              System.out.println("4.Kitfo");
             }
             if(food[9]==5)
             {
              System.out.println("5.Shiro");
             }
             if(food[9]==6)
             {
              System.out.println("6.Berbere");
             }
             if(food[9]==7)
             {
              System.out.println("7.Misir Wat");
             }
             if(food[9]==8)
             {
              System.out.println("8.Firfir");
             }
             if(food[9]==9)
             {
              System.out.println("9.Awaze Tibs");
             }
             if(food[9]==10)
             {
              System.out.println("10.Gomen");
             }
             break;
            }
            case 12:
            {
             food[10] = 12;
                char c='m';
             System.out.println("Hola!");
             System.out.println("                                       ");
             System.out.println("1.Tacos – Corn or flour tortillas filled with various ingredients like meats, beans, and vegetables, topped with salsa.");
             System.out.println("2.Enchiladas – Rolled tortillas filled with meat or cheese, smothered in chili sauce and often topped with cheese.");
             System.out.println("3.Mole Poblano – A rich, complex sauce made with chocolate, spices, and chili peppers, usually served over chicken.");
             System.out.println("4.Chiles Rellenos – Stuffed peppers (typically poblano) filled with cheese or meat, battered, and fried.");
             System.out.println("5.Tamales – Masa (corn dough) filled with meats, cheeses, or fruits, wrapped in corn husks, and steamed.");
             System.out.println("6.Guacamole – A creamy avocado dip mixed with lime juice, tomatoes, onions, and cilantro, often served with chips.");
             System.out.println("7.Ceviche – Fresh fish or seafood marinated in citrus juices, mixed with tomatoes, onions, and cilantro.");
             System.out.println("8.Quesadillas – Tortillas filled with cheese and other ingredients, folded and grilled until crispy.");
             System.out.println("9.Sopes – Thick corn tortillas topped with refried beans, meat, lettuce, cheese, and salsa.");
             System.out.println("10.Churros – Fried dough pastries, often sprinkled with sugar and cinnamon, sometimes served with chocolate sauce.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[0]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[0]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[0]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[0]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[0]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[0]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[0]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[0]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[0]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[1]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[1]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[1]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[1]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[1]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[1]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[1]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[1]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[1]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[2]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[2]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[2]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[2]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[2]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[2]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[2]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[2]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[2]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[3]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[3]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[3]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[3]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[3]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[3]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[3]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[3]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[3]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[4]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[4]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[4]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[4]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[4]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[4]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[4]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[4]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[4]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[5]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[5]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[5]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[5]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[5]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[5]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[5]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[5]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[5]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[6]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[6]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[6]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[6]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[6]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[6]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[6]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[6]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[6]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[7]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[7]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[7]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[7]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[7]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[7]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[7]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[7]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[7]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[8]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[8]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[8]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[8]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[8]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[8]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[8]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[8]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[8]==10)
             {
              System.out.println("10.Churros");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Tacos");
             }
             if(food[9]==2)
             {
             System.out.println("2.Enchiladas");
             }
             if(food[9]==3)
             {
              System.out.println("3.Mole Poblano");
             }
             if(food[9]==4)
             {
              System.out.println("4.Chiles Rellenos");
             }
             if(food[9]==5)
             {
              System.out.println("5.Tamales");
             }
             if(food[9]==6)
             {
              System.out.println("6.Guacamole");
             }
             if(food[9]==7)
             {
              System.out.println("7.Ceviche");
             }
             if(food[9]==8)
             {
              System.out.println("8.Quesadillas");
             }
             if(food[9]==9)
             {
              System.out.println("9.Sopes");
             }
             if(food[9]==10)
             {
              System.out.println("10.Churros");
             }
             break;
            }
            case 13:
            {
              food[10] = 13;
                char c='r';
             System.out.println("privet!"); 
             System.out.println("                                       ");
             System.out.println("1.Borscht – A vibrant beet soup often served hot or cold, typically with sour cream and dill.");
             System.out.println("2.Pelmeni – Dumplings filled with minced meat, served with butter or sour cream.");
             System.out.println("3.Blini – Thin pancakes or crepes, often filled with sweet or savory fillings like caviar, sour cream, or jam.");
             System.out.println("4.Olivier Salad – A hearty potato salad made with boiled vegetables, eggs, pickles, and diced meat or sausage.");
             System.out.println("5.Shchi – A traditional cabbage soup made with meat, vegetables, and sometimes sauerkraut.");
             System.out.println("6.Pirozhki – Baked or fried pastries filled with meat, vegetables, or sweet fillings like fruit or jam.");
             System.out.println("7.Kholodets – A savory meat jelly made from boiled meat and broth, chilled until set.");
             System.out.println("8.Caviar – Luxurious fish eggs, often served on blini or toast with crème fraîche.");
             System.out.println("9.Kvass – A fermented beverage made from rye bread, often slightly sweet and mildly alcoholic.");
             System.out.println("10.Syrniki – Sweet cheese pancakes made from cottage cheese, often served with sour cream or jam.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[0]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[0]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[0]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[0]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[0]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[0]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[0]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[0]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[0]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[1]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[1]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[1]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[1]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[1]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[1]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[1]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[1]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[1]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[2]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[2]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[2]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[2]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[2]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[2]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[2]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[2]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[2]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[3]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[3]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[3]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[3]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[3]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[3]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[3]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[3]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[3]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[4]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[4]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[4]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[4]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[4]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[4]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[4]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[4]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[4]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[5]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[5]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[5]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[5]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[5]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[5]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[5]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[5]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[5]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[6]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[6]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[6]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[6]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[6]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[6]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[6]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[6]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[6]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[7]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[7]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[7]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[7]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[7]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[7]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[7]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[7]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[7]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[8]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[8]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[8]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[8]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[8]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[8]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[8]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[8]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[8]==10)
             {
              System.out.println("10.Syrniki");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Borscht");
             }
             if(food[9]==2)
             {
             System.out.println("2.Pelmeni");
             }
             if(food[9]==3)
             {
              System.out.println("3.Blini");
             }
             if(food[9]==4)
             {
              System.out.println("4.Olivier Salad");
             }
             if(food[9]==5)
             {
              System.out.println("5.Shchi");
             }
             if(food[9]==6)
             {
              System.out.println("6.Pirozhki");
             }
             if(food[9]==7)
             {
              System.out.println("7.Kholodets");
             }
             if(food[9]==8)
             {
              System.out.println("8.Caviar");
             }
             if(food[9]==9)
             {
              System.out.println("9.Kvass");
             }
             if(food[9]==10)
             {
              System.out.println("10.Syrniki");
             }
             break;
            }
            case 14:
            {
             food[10] = 14;
                char c='v';
             System.out.println("Xin chào!"); 
             System.out.println("                                       ");
             System.out.println("1.Pho – A fragrant noodle soup with beef or chicken, herbs, and a flavorful broth, often enjoyed for breakfast.");
             System.out.println("2.Banh Mi – A Vietnamese sandwich featuring a crispy baguette filled with meats, pickled vegetables, and fresh herbs.");
             System.out.println("3.Spring Rolls (Gio Lua) – Fresh or fried rolls filled with vegetables, herbs, and shrimp or pork, served with dipping sauce.");
             System.out.println("4.Bun Cha – Grilled pork served over vermicelli noodles with fresh herbs and a side of dipping sauce.");
             System.out.println("5.Com tam (Broken Rice) – A dish made from broken rice grains, typically served with grilled pork and various accompaniments.");
             System.out.println("6.Hue-style Beef Noodle Soup (Bun Bo Hue) – A spicy and aromatic noodle soup with beef, lemongrass, and rice noodles.");
             System.out.println("7.Cha Gio (Fried Spring Rolls) – Crispy fried rolls filled with a mixture of pork, shrimp, and vegetables, often served with nuoc cham.");
             System.out.println("8.Mi Quang – A regional noodle dish from Quang Nam province, made with turmeric rice noodles, pork, shrimp, and peanuts.");
             System.out.println("9.Cao Lau – A noodle dish from Hoi An featuring thick noodles, pork, and fresh herbs, garnished with crispy rice crackers.");
             System.out.println("10.Che – A sweet dessert soup made from a variety of ingredients, including beans, fruit, and coconut milk, enjoyed as a refreshing treat.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[0]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[0]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[0]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[0]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[0]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[0]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[0]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[0]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[0]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[1]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[1]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[1]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[1]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[1]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[1]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[1]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[1]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[1]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[2]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[2]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[2]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[2]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[2]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[2]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[2]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[2]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[2]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[3]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[3]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[3]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[3]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[3]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[3]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[3]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[3]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[3]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[4]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[4]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[4]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[4]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[4]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[4]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[4]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[4]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[4]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[5]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[5]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[5]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[5]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[5]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[5]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[5]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[5]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[5]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[6]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[6]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[6]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[6]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[6]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[6]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[6]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[6]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[6]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[7]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[7]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[7]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[7]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[7]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[7]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[7]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[7]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[7]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[8]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[8]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[8]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[8]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[8]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[8]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[8]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[8]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[8]==10)
             {
              System.out.println("10.Che");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Pho");
             }
             if(food[9]==2)
             {
             System.out.println("2.Banh Mi");
             }
             if(food[9]==3)
             {
              System.out.println("3.Spring Rolls");
             }
             if(food[9]==4)
             {
              System.out.println("4.Bun Cha");
             }
             if(food[9]==5)
             {
              System.out.println("5.Com tam");
             }
             if(food[9]==6)
             {
              System.out.println("6.Hue-style Beef Noodle Soup");
             }
             if(food[9]==7)
             {
              System.out.println("7.Cha Gio");
             }
             if(food[9]==8)
             {
              System.out.println("8.Mi Quang");
             }
             if(food[9]==9)
             {
              System.out.println("9.Cao Lau");
             }
             if(food[9]==10)
             {
              System.out.println("10.Che");
             }
             break;
            }
            case 15:
            {
             food[10] = 15;
                char c='s';
             System.out.println("Hallo!");  
             System.out.println("                                       ");
             System.out.println("1.Braaivleis – Grilled meat, often beef, lamb, or boerewors, cooked over an open fire, typically enjoyed at social gatherings.");
             System.out.println("2.Bobotie – A savory baked dish of spiced minced meat topped with a custard-like egg mixture, often served with yellow rice.");
             System.out.println("3.Bunny Chow – A hollowed-out loaf of bread filled with spicy curry, originating from the Indian community in Durban.");
             System.out.println("4.Potjiekos – A slow-cooked stew prepared in a cast-iron pot over an open flame, featuring meat and vegetables.");
             System.out.println("5.Samosas – Deep-fried pastry pockets filled with spiced potatoes, peas, or meat, reflecting Indian influence in South Africa.");
             System.out.println("6.Koeksisters – Sweet, syrup-soaked pastries braided and fried until crispy, often enjoyed as a dessert or snack.");
             System.out.println("7.Pap and Chakalaka – A staple maize porridge served with a spicy vegetable relish, commonly eaten with meat dishes.");
             System.out.println("8.Melktert – A traditional milk tart made with a creamy custard filling in a pastry crust, often sprinkled with cinnamon.");
             System.out.println("9.Vetkoek – Deep-fried dough balls that can be filled with savory mince or sweet jams, popular as a street food snack.");
             System.out.println("10.Gatsby – A large submarine sandwich filled with French fries, spiced meats, and various sauces, a popular street food in Cape Town.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[0]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[0]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[0]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[0]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[0]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[0]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[0]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[0]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[0]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[1]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[1]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[1]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[1]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[1]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[1]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[1]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[1]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[1]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[2]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[2]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[2]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[2]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[2]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[2]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[2]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[2]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[2]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[3]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[3]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[3]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[3]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[3]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[3]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[3]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[3]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[3]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[4]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[4]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[4]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[4]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[4]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[4]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[4]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[4]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[4]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[5]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[5]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[5]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[5]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[5]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[5]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[5]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[5]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[5]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[6]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[6]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[6]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[6]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[6]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[6]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[6]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[6]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[6]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[7]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[7]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[7]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[7]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[7]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[7]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[7]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[7]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[7]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[8]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[8]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[8]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[8]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[8]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[8]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[8]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[8]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[8]==10)
             {
              System.out.println("10.Gatsby");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Braaivleis");
             }
             if(food[9]==2)
             {
             System.out.println("2.Bobotie");
             }
             if(food[9]==3)
             {
              System.out.println("3.Bunny Chow");
             }
             if(food[9]==4)
             {
              System.out.println("4.Potjiekos");
             }
             if(food[9]==5)
             {
              System.out.println("5.Samosas");
             }
             if(food[9]==6)
             {
              System.out.println("6.Koeksisters");
             }
             if(food[9]==7)
             {
              System.out.println("7.Pap and Chakalaka");
             }
             if(food[9]==8)
             {
              System.out.println("8.Melktert");
             }
             if(food[9]==9)
             {
              System.out.println("9.Vetkoek");
             }
             if(food[9]==10)
             {
              System.out.println("10.Gatsby");
             }
             break;
            }
            case 16:
            {
             food[10] = 16;
                char c='j';
             System.out.println("Kon'nichiwa!");  
             System.out.println("                                       ");
             System.out.println("1.Tonkotsu Ramen – Rich and creamy pork bone broth ramen topped with sliced pork, green onions, and nori. ");
             System.out.println("2.Okonomiyaki – Savory pancakes filled with various ingredients like cabbage, meat, and topped with a special sauce and bonito flakes. ");
             System.out.println("3.Kushikatsu – Deep-fried skewers of meat and vegetables served with a tangy dipping sauce. ");
             System.out.println("4.Takoyaki – Octopus-filled savory balls made from batter, cooked in a special molded pan, and topped with takoyaki sauce and bonito flakes.");
             System.out.println("5.Bento Box – A traditional lunch box featuring a variety of small dishes, including rice, fish, meat, and pickled vegetables.");
             System.out.println("6.Yakisoba – Stir-fried noodles with vegetables and meat, flavored with a sweet and savory sauce.");
             System.out.println("7.Chikuzenni – A simmered dish of root vegetables, chicken, and konnyaku, flavored with soy sauce and mirin.");
             System.out.println("8.Goya Champuru – A stir-fry dish featuring bitter melon, tofu, and pork, commonly found in Okinawa.");
             System.out.println("9.Soki Soba – Okinawan soba noodles served with tender pork spare ribs in a rich broth.");
             System.out.println("10.Miso Katsu – A regional variation of tonkatsu topped with a rich red miso sauce, popular in Nagoya.");
             System.out.println("Enter 0 to exit ordering");

             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break;   
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
                          if(food[0]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[0]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[0]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[0]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[0]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[0]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[0]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[0]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[0]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[0]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[1]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[1]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[1]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[1]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[1]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[1]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[1]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[1]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[1]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[2]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[2]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[2]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[2]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[2]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[2]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[2]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[2]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[2]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[3]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[3]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[3]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[3]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[3]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[3]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[3]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[3]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[3]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[4]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[4]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[4]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[4]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[4]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[4]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[4]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[4]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[4]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[5]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[5]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[5]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[5]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[5]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[5]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[5]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[5]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[5]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[6]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[6]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[6]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[6]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[6]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[6]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[6]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[6]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[6]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[7]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[7]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[7]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[7]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[7]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[7]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[7]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[7]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[7]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[8]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[8]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[8]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[8]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[8]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[8]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[8]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[8]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[8]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Tonkotsu Ramen");
             }
             if(food[9]==2)
             {
             System.out.println("2.Okonomiyaki");
             }
             if(food[9]==3)
             {
              System.out.println("3.Kushikatsu");
             }
             if(food[9]==4)
             {
              System.out.println("4.Takoyaki");
             }
             if(food[9]==5)
             {
              System.out.println("5.Bento Box");
             }
             if(food[9]==6)
             {
              System.out.println("6.Yakisoba");
             }
             if(food[9]==7)
             {
              System.out.println("7.Chikuzenni");
             }
             if(food[9]==8)
             {
              System.out.println("8.Goya Champuru");
             }
             if(food[9]==9)
             {
              System.out.println("9.Soki Soba");
             }
             if(food[9]==10)
             {
              System.out.println("10.Miso Katsu");
             }
             break;
            }
            case 17:
            {
             food[10] = 17;
                char c='i';
             System.out.println("vanakkam!"); 
             System.out.println("                                       ");
             System.out.println("1.Dosa – A thin, crispy crepe made from fermented rice and lentil batter, often served with chutney and sambar.     ");
             System.out.println("2.Idli – Soft, fluffy steamed rice cakes typically served with coconut chutney and sambar. ");
             System.out.println("3.Sambar – A spicy lentil soup with vegetables and tamarind, often served with rice or dosa. ");
             System.out.println("4.Vada – Deep-fried lentil fritters, crispy on the outside and soft on the inside, often served with chutneys.");
             System.out.println("5.Uttapam – A thick, savory pancake topped with onions, tomatoes, and green chilies, served with chutney.");
             System.out.println("6.Biryani – A fragrant rice dish cooked with marinated meat or vegetables, flavored with spices and herbs.");
             System.out.println("7.Pongal – A comfort dish made from rice and lentils, typically spiced with black pepper, ginger, and cumin.");
             System.out.println("8.Rasam – A tangy soup made with tamarind, tomatoes, and spices, often enjoyed with rice.");
             System.out.println("9.Appam – A soft and fluffy rice pancake with a crispy edge, usually served with coconut milk or vegetable stew.");
             System.out.println("10.Payasam – A sweet dessert made from rice or vermicelli, cooked in milk and flavored with cardamom and nuts.");
             System.out.println("Enter 0 to exit ordering");
                
             for(int i=0;1<10;i++)
             {
              int b=ac.nextInt();
              if(b==0)
              {
               break; 
              }
              if(b>0)
              {
               food[i]=b;  
              }   
             }
             if(food[0]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[0]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[0]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[0]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[0]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[0]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[0]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[0]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[0]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[0]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[1]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[1]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[1]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[1]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[1]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[1]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[1]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[1]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[1]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[1]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[2]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[2]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[2]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[2]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[2]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[2]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[2]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[2]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[2]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[2]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[3]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[3]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[3]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[3]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[3]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[3]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[3]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[3]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[3]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[3]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[4]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[4]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[4]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[4]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[4]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[4]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[4]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[4]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[4]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[4]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[5]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[5]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[5]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[5]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[5]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[5]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[5]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[5]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[5]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[5]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[6]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[6]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[6]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[6]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[6]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[6]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[6]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[6]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[6]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[6]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[7]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[7]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[7]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[7]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[7]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[7]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[7]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[7]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[7]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[7]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[8]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[8]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[8]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[8]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[8]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[8]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[8]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[8]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[8]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[8]==10)
             {
              System.out.println("10.Payasam");
             }
             
             if(food[9]==1)
             {
              System.out.println("1.Dosa");
             }
             if(food[9]==2)
             {
             System.out.println("2.Idli");
             }
             if(food[9]==3)
             {
              System.out.println("3.Sambar");
             }
             if(food[9]==4)
             {
              System.out.println("4.Vada");
             }
             if(food[9]==5)
             {
              System.out.println("5.Uttapam");
             }
             if(food[9]==6)
             {
              System.out.println("6.Biriyani");
             }
             if(food[9]==7)
             {
              System.out.println("7.Pongal");
             }
             if(food[9]==8)
             {
              System.out.println("8.Rasam");
             }
             if(food[9]==9)
             {
              System.out.println("9.Appam");
             }
             if(food[9]==10)
             {
              System.out.println("10.Payasam");
             }
             break;
            }
            
        }
        return(food);
         
     } 
    public int Getbillof(int c,int m[])
    {
        String[] Total= {" "," "," "," "," "," "," "," "," "};
        int a =0;
        switch(c)
        {
            case 1:
            {
                String[] MENU= {" ","Baguette","Escargot", "Onion Soup", "Croque Monsieur","Nicoise Salad","Ratatouille","Coq au Vin","Dauphinois Potatoes","Croissant","Quiche Lorraine"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 2:
            {
                String[] MENU= {" ","Peking Duck","Sweet and Sour Pork", "Dim Sum", "Kung Pao Chicken","Mapo Tofu","Hot Pot","Chow Mein","Xiaolongbao","Fried Rice","Spring Rolls"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 3:
            {
                String[] MENU= {" ","Baguette","Escargot", "Onion Soup", "Croque Monsieur","Nicoise Salad","Ratatouille","Coq au Vin","Dauphinois Potatoes","Croissant","Quiche Lorraine"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 4:
            {
                String[] MENU= {" ","Peking Duck","Sweet and Sour Pork", "Dim Sum", "Kung Pao Chicken","Mapo Tofu","Hot Pot","Chow Mein","Xiaolongbao","Fried Rice","Spring Rolls"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 5:
            {
                String[] MENU = {" ","Paella", "Tapas", "Tortilla Española", "Gazpacho", "Fabada Asturiana", "Patatas Bravas", "Jamón Ibérico", "Pulpo a la Gallega", "Croquetas", "Pisto"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
             case 6:
            {
                String[] MENU = {" ","Hummus", "Tabbouleh", "Falafel", "Kibbeh", "Shawarma", "Baba Ghanoush", "Manakish", "Fattoush", "Warak Enab (Stuffed Grape Leaves)", "Baklava"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 7:
            {
                String[] MENU = {" ", "Tagine", "Couscous", "Harira", "Pastilla (Bastilla)", "Mechoui", "Zaalouk", "Rfissa", "Briouats", "Chebakia", "Msemen"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 8:
            {
                String[] MENU = {" ","Kebabs (Shish, Döner, Adana)", "Baklava", "Lahmacun", "Menemen", "Meze", "Dolma", "Manti", "Pide", "Künefe", "Börek"};
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 9:
            {
		String[] MENU = {" ","Pad Thai",  "Tom Yum Goong (Spicy Shrimp Soup)",  "Green Curry (Gaeng Keow Wan)",  "Som Tum (Papaya Salad)",  "Massaman Curry",  "Pad Kra Pao (Basil Chicken)", "Tom Kha Gai (Coconut Chicken Soup)", "Mango Sticky Rice", "Panang Curry", "Thai Satay"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
             case 10:
            {
		String[] MENU = {" ","Feijoada", "Pão de Queijo", "Coxinha", "Brigadeiro", "Churrasco", "Acarajé", "Moqueca", "Farofa", "Vatapá", "Pastel"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 11:
            {
		String[] MENU = {" ","Injera", "Doro Wat", "Tibs", "Kitfo", "Shiro", "Berbere", "Misir Wat", "Firfir", "Awaze Tibs", "Gomen"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 12:
            {
		String[] MENU = {" ","Tacos", "Enchiladas", "Mole Poblano", "Chiles Rellenos", "Tamales", "Guacamole", "Ceviche", "Quesadillas", "Sopes", "Churros"};
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 13:
            {
		String[] MENU = {" ","Borscht", "Pelmeni", "Blini", "Olivier Salad", "Shchi", "Pirozhki", "Kholodets", "Caviar", "Kvass", "Syrniki"};
                
                int[] Bill1={0,92,187,55,113,204,147,69,158,224,178};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }
            case 14:
            {
		String[] MENU = {" ","Pho", "Banh Mi", "Spring Rolls (Gio Lua)", "Bun Cha", "Com tam (Broken Rice)", "Hue-style Beef Noodle Soup (Bun Bo Hue)", "Cha Gio (Fried Spring Rolls)", "Mi Quang", "Cao Lau", "Che"};
                
                int Bill1[] = {325, 48, 731, 120, 549, 916, 237, 84, 680, 315, 542};
                int TBill=0;
                
                for(int i=0;i<=9;i++)
                {
                 a=m[i];
                if(a>0)
                {
                 TBill+=Bill1[a];
                 Total[i]=MENU[a];
                 System.out.println(Total[i]+" $"+Bill1[a]);
                }
                else
                {
                 break;
                }
                }
                System.out.println("Total Bill = $"+TBill);
                break;
            }

        }
        return a;
    }
    }