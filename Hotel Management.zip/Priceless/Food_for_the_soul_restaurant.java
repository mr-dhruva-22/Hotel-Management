import mypack.met1;   
import java.util.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
class Food_for_the_soul_restaurant
{
    int food[]=new int [11];
    public static int executeCommandLine(final String commandLine,
                                     final boolean printOutput,
                                     final boolean printError)
    throws IOException, InterruptedException
{
    Runtime runtime = Runtime.getRuntime();
    Process process = runtime.exec(commandLine);

    if (printOutput)
    {
        BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        System.out.println("Output:  " + outputReader.readLine());
    }

    if (printError)
    {
        BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
        System.out.println("Error:  " + errorReader.readLine());
    }

    return process.waitFor();
}
    Food_for_the_soul_restaurant()
    {
        food[0] = 0;
        food[1] = 0;
        food[2] = 0;
        food[3] = 0;
        food[4] = 0;
        food[5] = 0;
        food[6] = 0;
        food[7] = 0;
        food[8] = 0;
        food[9] = 0;
        food[10] = 0;
        
        System.out.println("\n-----------------------------------------");
        System.out.println(" Welcome to 'Food for the Soul' Restaurant ");
        System.out.println("-----------------------------------------");
        System.out.println("Please select your preferred cuisine:");
        System.out.println("1. French     2. Chinese     3. Italian");
        System.out.println("4. Greek      5. Spanish     6. Lebanese");
        System.out.println("7. Moroccan   8. Turkish     9. Thai");
        System.out.println("10. Brazilian 11. Ethiopian  12. Mexican");
        System.out.println("13. Russian   14. Vietnamese 15. South African");
        System.out.println("16. Japanese  17. Indian");
        System.out.println("-----------------------------------------");
    

    }
    
public static void main(String args[])
{
 Scanner sc=new Scanner(System.in);
 for(int i=1;i<=10;i++)
{
 met1 C1=new met1();
 Food_for_the_soul_restaurant C2=new Food_for_the_soul_restaurant();
 int a=sc.nextInt();
 int menu[]=C1.Getfoodof(a);
 int c=menu[10];
 C1.Getbillof(c,menu);
 System.out.println("Do you want to continue ordering?");
 System.out.println("Enter 1 for continuing and 0 for exiting");
 int f=sc.nextInt();
 
 if(f==1)
 {
   
 }
 else
 {
  System.out.println("Thank You");
  System.exit(0);
 }
}

}
}